// TMNT OS Kernel - Main Core
#include "drivers/vga/vga.h"
#include "drivers/keyboard/keyboard.h"
#include "system/image_injector.h"
#include "fs/tmnt_fs.h"
#include "shell/shell.h"
#include "system/config.h"
#include "system/memory.h"
#include "system/string.h"
#include "kernel/idt.h"

// Forward declarations
void display_tmnt_boot_logo();
void check_image_updates();

void kernel_main() {
    memory_init();
    vga_init();
    keyboard_init();
    idt_init();
    fs_init();
    config_init();
    
    vga_clear_screen();
    vga_set_bg_color(VGA_COLOR_GREEN);
    
    display_tmnt_boot_logo();
    
    image_injector_init();
    scan_for_user_images();
    
    vga_set_fg_color(VGA_COLOR_WHITE);
    vga_print_centered("TMNT OS v1.0 - Shell Shock!", 10);
    vga_set_fg_color(VGA_COLOR_YELLOW);
    vga_print_centered("Type 'cowabunga' for help", 11);
    vga_print_centered("Drop images in /user/assets to customize!", 12);
    
    shell_init();
    
    while(1) {
        shell_process();
        check_image_updates();
    }
}

void display_tmnt_boot_logo() {
    if(fs_file_exists("/system/assets/boot_logo/current")) {
        render_image_to_vga("/system/assets/boot_logo/current", 0, 0);
    } else {
        vga_set_fg_color(VGA_COLOR_LIGHT_GREEN);
        vga_print_at("  _____ __  __ _   _ _____  ", 20, 2);
        vga_print_at(" |_   _|  \\/  | \\ | |_   _| ", 20, 3);
        vga_print_at("   | | | .  . |  \\| | | |   ", 20, 4);
        vga_print_at("   | | | |\\/| | . ` | | |   ", 20, 5);
        vga_print_at("   |_| |_|  |_|_| \\_| |_|   ", 20, 6);
        vga_print_at("     OPERATING SYSTEM        ", 20, 7);
    }
}

void check_image_updates() {
    static int scan_counter = 0;
    scan_counter++;
    if(scan_counter >= 1000) {
        scan_for_user_images();
        scan_counter = 0;
    }
}