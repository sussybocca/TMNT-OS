[bits 32]

; --- THE MULTIBOOT HEADER (GRUB requirement) ---
section .multiboot
align 4
    dd 0x1BADB002              ; Magic number for Multiboot 1
    dd 0x00                    ; Flags
    dd -(0x1BADB002 + 0x00)    ; Checksum

; --- THE ENTRY POINT ---
section .text
global _start

extern kernel_main

_start:
    ; Set up a safe stack pointer for 32-bit mode operations
    mov esp, stack_space
    
    ; Clear the screen and print our greeting string
    mov esi, msg_tmnt_boot
    call print_string_32
    
    ; Jump to the C kernel
    call kernel_main
    
    ; If kernel_main returns, halt safely
.hang:
    hlt                         ; Safely halt the CPU
    jmp .hang                   ; Loop infinitely if an interrupt wakes it up

; --- 32-BIT VGA TEXT MODE PRINTING FUNCTION ---
print_string_32:
    mov edi, 0xB8000            ; Address of Video Memory (Top-Left of Screen)
    mov ah, 0x0F                ; Text Attribute: White text on Black background

.print_loop:
    lodsb                       ; Load next byte from ESI into AL, increments ESI
    or al, al                   ; Check if character is 0 (End of String)
    jz .done                    ; If 0, exit the function
    
    mov [edi], ax               ; Write character (AL) and attribute (AH) to screen
    add edi, 2                  ; Move video memory pointer to next character cell
    jmp .print_loop

.done:
    ret

; --- DATA SECTION ---
section .data
; Your custom OS messages
msg_tmnt_boot db 'TMNT OS v1.0 - Cowabunga!', 0

; --- UNINITIALIZED DATA SECTION (STACK SETUP) ---
section .bss
align 4
resb 8192                       ; Reserve 8KB of memory for the OS stack space
stack_space: